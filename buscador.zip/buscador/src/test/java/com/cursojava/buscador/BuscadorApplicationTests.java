package com.cursojava.buscador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BuscadorApplicationTests {

	@Test
	void contextLoads() {
	}

}
